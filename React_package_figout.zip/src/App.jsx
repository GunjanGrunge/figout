import "./App.css"
import logo from "../src/Shared/fio.png"
import image2 from "../src/Shared/thumbnail_20230421_160119.jpg"
import { FaYoutube } from "react-icons/fa";
import { FaSpotify } from "react-icons/fa";
import { FaInstagram } from "react-icons/fa6";
import { FaTwitter } from "react-icons/fa";
import { IoMdMic } from "react-icons/io";
import { useEffect, useState } from "react";
import InfiniteScroll from './Components/Card'
  


function App()

    

{


    const apiKey = 'AIzaSyCVFL9-auB4M7IGlU-kEtGqEHVVwDaAIL8';
    const channelId = 'UC2OM05m1q4RSE8eFrQ-oXYQ';

    const date = new Date().toISOString().split('T')[0]



    


    return(
        <>
        {/* header */}
        <div className = "Header">
                <div className="Logotag">
                <img src = {logo} alt = "test" className = "Logo"/>
                        <p>#figureItoutWithSaaj</p>
                </div>
                <div className="social">
                    <div id="youtube"> <a href = "https://youtube.com/@FigureitOutwithSaaj?si=Uy7WaZLjl8g9ry4p"> <FaYoutube style = {{color:'#ff0000',width:'30px',height:'25px'}}/></a> </div>
                    <div id = "spotify"><a href = "https://open.spotify.com/show/1cWkk16dXiWGbaiGv6o4Dx?si=uj2k3-xiScClnGfN_ICVag"><FaSpotify style = {{color:'#1db954',width:'30px',height:'25px'}}/></a></div>
                    <div id = "instagram"><a href = "https://www.instagram.com/figureitoutwithsaaj?igsh=NmoxbTJ2YXd3aGRm"><FaInstagram style = {{color:'#c13584',width:'30px',height:'25px'}}/></a></div>
                    <div id = "twitter"><a href = "Www.twitter.com/maverick_3"><FaTwitter style = {{color:'#1da1f2',width:'30px',height:'25px'}}/></a></div>
                </div>
        </div>
        
        

        {/* First Image*/}
        <div className="hero">
            <div className="overlay">
                <p>Tune into my podcast You can bribe me with Jack Daniels!</p>
            </div>
        </div>



        {/* Recent Podcasts from youtube API */}
        <div className="yellowsection">
        <h1 className="yellowsectionh1">RECENT PODCASTS</h1>
        <div className="recentpodcast">
            <div className="Card1">
                <InfiniteScroll/>
            </div>
        </div>
        </div>




        {/* Below Content */}
        <div className="writeup">
        <p className="p1">Welcome to Figure It Out! The podcast where we tackle life's puzzles, both big and small.
            Join me as I explore personal, professional, and everything-in-between with incredible guests from all walks of life. 
        </p>
        <p className="p2">
            They'll share their stories, triumphs, setbacks, and valuable insights to help you navigate your own journey and make well-informed decisions.
        </p>
        </div>



        {/* Microphone icon and all */}
        <div className="register">
        <div id = "mic">
        <IoMdMic size = {30} color = "#008000"/>
        </div>
        <div>
        <p>Figure it Out with Me - Be on my Podcast</p>
        </div>
        </div>



        {/* Digital Marketing */}
        <div className="write_up">
        <img src={image2} alt=""/>
        <br/><br/>
        <span>Hi there,  I'm Sajan Gupta, a 33-year-old digital marketer with over 11 years of experience. When I'm not busy crafting killer campaigns, 
            I'm an avid 
            athlete and can't get enough of meeting new people and jamming to my favorite tunes. let's connect?</span>
        </div>

        {/* Footer */}
        <div className="footer">

            <div className="disclaimer">
                <p> The views, thoughts, and opinions expressed are the speaker’s own . The material and information presented here is for general information purposes only.<br/>
                    FIO are the property of its owner and its use does not imply endorsement of or opposition to any specific organization, product, or service. </p>
            
            </div>

        
        {/* Copyrights */}
            <div className="copyright">
                <div>
                <p>Copyrights figout  <span id="year">{date} </span> <br/>
                            <span><a href="https://www.TheAiChamp.com" >TheAiChamp</a></span>
                
                    </p>
                </div>
            </div>

        </div>

            
        </>
    )
}
export default App;