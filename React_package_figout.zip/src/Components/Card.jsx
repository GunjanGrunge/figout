import React, { useEffect, useState } from 'react';
import './Card.css'; 

const InfiniteScroll = () => {
  useEffect(() => {
    const scrollContent = document.getElementById('scrollContent');
    // Duplicate the content to create an infinite loop
    scrollContent.innerHTML += scrollContent.innerHTML;
  }, []);



const apiKey = 'AIzaSyCVFL9-auB4M7IGlU-kEtGqEHVVwDaAIL8';
const channelId = 'UC2OM05m1q4RSE8eFrQ-oXYQ';

const [videos,setVideos] = useState([])


async function fetchVideos(){
    try{
        const response = await fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=${channelId}&maxResults=50&key=${apiKey}`);
        if(!response.ok){
            throw new Error('Network error in fetching the data')
        }
        const data = await response.json()
        console.log(data.items)
        setVideos(data?.items)
    }
    catch(error){
        console.error(`Error in response ${error}`)
    }
}


useEffect(()=>{
    fetchVideos();
},[])

  return (
    <div className="scroll-container">
      <div className="scroll-content" id="scrollContent">
        {/* Add your iframe elements here with YouTube videos */}
        
        {/* {videos.map((item)=>(
             <div className="scroll-card" key = {item.etag}>
             <iframe title="Video" width="300" height="250" src={item} frameBorder="0" allowFullScreen></iframe>
           </div>
        ))} */}

        <div className="scroll-card">
          <iframe title="Video 1" width="300" height="250" src="https://www.youtube.com/embed/YOUR_VIDEO_ID_1" frameBorder="0" allowFullScreen></iframe>
        
        </div>
        <div className="scroll-card">
          <iframe title="Video 1" width="300" height="250" src="https://www.youtube.com/embed/YOUR_VIDEO_ID_1" frameBorder="0" allowFullScreen></iframe>
        </div>
        <div className="scroll-card">
          <iframe title="Video 1" width="300" height="250" src="https://www.youtube.com/embed/YOUR_VIDEO_ID_1" frameBorder="0" allowFullScreen></iframe>
        </div>



        {/* Repeat the above card structure for each video */}
      </div>
    </div>
  );
};

export default InfiniteScroll;
